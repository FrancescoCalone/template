package apsd.interfaces.containers.iterators;

/** Interface: Iteratore all'indietro mutabile. */
public interface MutableBackwardIterator<Data> extends MutableIterator<Data>, BackwardIterator<Data> {}
