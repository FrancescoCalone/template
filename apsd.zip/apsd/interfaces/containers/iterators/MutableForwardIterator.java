package apsd.interfaces.containers.iterators;

/** Interface: Iteratore in avanti mutabile. */
public interface MutableForwardIterator<Data> extends MutableIterator<Data>, ForwardIterator<Data> {}

