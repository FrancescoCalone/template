package apsd.classes.containers.sequences;

import apsd.classes.containers.sequences.abstractbases.DynLinearVectorBase;
import apsd.classes.utilities.Natural;
import apsd.interfaces.containers.base.TraversableContainer;

/** Object: Concrete dynamic (linear) vector implementation. */
public class DynVector<Data> extends DynLinearVectorBase<Data> {

  public DynVector(){
    super((TraversableContainer<Data>) null);
    ArrayAlloc(Natural.ZERO);
  }

  public DynVector(Natural inisize) {
    super((TraversableContainer<Data>) null);
    ArrayAlloc(inisize);
  }

  public DynVector(TraversableContainer<Data> con) {
    super(con);
  }

  protected DynVector(Data[] arr) {
    super((TraversableContainer<Data>) null);
    this.arr = arr;
  }

  // NewVector
  @Override
  protected DynVector<Data> NewVector(Data[] arr1) {
    DynVector<Data> vec = new DynVector<>(arr1);
    return vec;
  }

}
